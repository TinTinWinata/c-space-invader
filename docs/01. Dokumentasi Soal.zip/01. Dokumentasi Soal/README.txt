Panduan Dokumentasi Soal NAR
----------------------------

----------
| Header |
----------
- Sesuaikan jenis soal (Assignment / Mandatory / LevelUp)
- Tambahkan keterangan detail soal [Subject][Day][Type]
	cth: CH2Onsite

----------
| Materi |
----------
- Symbol list menggunakan disc (bulat hitam)
- Font
	* Calibri
	* Size: 12
	* Align Left
	* Spacing 1.5

--------
| Soal |
--------
- Judul	
	* Calibri
	* Size: 14
	* Bold
	* Align Center

- Konten
	* Calibri	
	* Size: 12
	* Align Justify
	* Indentation: 1.27cm
	* Spacing 1.5

- Gambar
	* Lebar: menyesuaikan lebar halaman seperti di contoh template dokumentasi
	* Align Center
	* Border
		- Solid
		- 1pt
		- Black

- Keterangan Gambar
	* Calibri
	* Size: 10
	* Bold
	* Align Center
	* Format: Figure [nomor]. [keterangan]
		cth: Figure 1. Background Image